<?php

namespace Telegram\Bot\Exceptions;

use Exception;

/**
 * Class TelegramUndefinedPropertyException.
 */
class TelegramUndefinedPropertyException extends Exception
{
}
